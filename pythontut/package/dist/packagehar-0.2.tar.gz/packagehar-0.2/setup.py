
from setuptools import setup
setup(name="packagehar",
        version="0.2",
        description="This is code with harry package",
        Long_description="This is a very very long description",
        author="parthcd Patel",
        package=["pakage parth"],
        install_requires=[] 
    )